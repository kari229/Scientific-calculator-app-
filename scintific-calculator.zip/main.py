import tkinter as tk
import math

def click(value):
    current = entry.get()
    entry.delete(0, tk.END)
    entry.insert(tk.END, current + str(value))

def clear():
    entry.delete(0, tk.END)

def calculate():
    try:
        result = eval(entry.get())
        entry.delete(0, tk.END)
        entry.insert(tk.END, str(result))
    except:
        entry.delete(0, tk.END)
        entry.insert(tk.END, "Error")

def scientific(func):
    try:
        value = float(entry.get())
        
        if func == "sin":
            result = math.sin(math.radians(value))
        elif func == "cos":
            result = math.cos(math.radians(value))
        elif func == "tan":
            result = math.tan(math.radians(value))
        elif func == "sqrt":
            result = math.sqrt(value)
        elif func == "log":
            result = math.log10(value)

        entry.delete(0, tk.END)
        entry.insert(tk.END, str(result))
    except:
        entry.delete(0, tk.END)
        entry.insert(tk.END, "Error")

# Window
root = tk.Tk()
root.title("Scientific Calculator")
root.geometry("350x450")

# Display
entry = tk.Entry(root, font=("Arial", 20), justify="right")
entry.pack(fill="both", ipadx=8, ipady=15, padx=10, pady=10)

# Buttons
frame = tk.Frame(root)
frame.pack()

buttons = [
    ['7', '8', '9', '/'],
    ['4', '5', '6', '*'],
    ['1', '2', '3', '-'],
    ['0', '.', '=', '+']
]

for row in buttons:
    row_frame = tk.Frame(frame)
    row_frame.pack(expand=True, fill="both")
    for btn in row:
        action = calculate if btn == '=' else lambda x=btn: click(x)
        tk.Button(row_frame, text=btn, font=("Arial", 16),
                  command=action, width=5, height=2).pack(side="left", expand=True, fill="both")

# Scientific buttons
sci_frame = tk.Frame(root)
sci_frame.pack(fill="both")

for func in ["sin", "cos", "tan", "sqrt", "log"]:
    tk.Button(sci_frame, text=func, font=("Arial", 14),
              command=lambda f=func: scientific(f)).pack(side="left", expand=True, fill="both")

# Clear button
tk.Button(root, text="Clear", font=("Arial", 14),
          command=clear).pack(fill="both", padx=10, pady=10)

root.mainloop()